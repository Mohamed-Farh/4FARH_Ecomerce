<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>

    <!-- Content Row -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.dashboard.statistics-component', [])->html();
} elseif ($_instance->childHasBeenRendered('9hFSro6')) {
    $componentId = $_instance->getRenderedChildComponentId('9hFSro6');
    $componentTag = $_instance->getRenderedChildComponentTagName('9hFSro6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9hFSro6');
} else {
    $response = \Livewire\Livewire::mount('backend.dashboard.statistics-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('9hFSro6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Content Row -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.dashboard.chart-component', [])->html();
} elseif ($_instance->childHasBeenRendered('KSQ9eHj')) {
    $componentId = $_instance->getRenderedChildComponentId('KSQ9eHj');
    $componentTag = $_instance->getRenderedChildComponentTagName('KSQ9eHj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KSQ9eHj');
} else {
    $response = \Livewire\Livewire::mount('backend.dashboard.chart-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('KSQ9eHj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\course\ecommerce\resources\views/backend/index.blade.php ENDPATH**/ ?>