<div class="d-flex">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('frontend.cart')); ?>">
            <i class="fas fa-dolly-flatbed mr-1 text-gray"></i>
            <small class="text-gray">(<?php echo e($cartCount); ?>)</small>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('frontend.wishlist')); ?>">
            <i class="far fa-heart mr-1"></i>
            <small class="text-gray"> (<?php echo e($wishlistCount); ?>)</small>
        </a>
    </li>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\course\ecommerce\resources\views/livewire/frontend/carts.blade.php ENDPATH**/ ?>