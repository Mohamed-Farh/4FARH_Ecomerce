@extends('layouts.admin')
@section('content')

    No edit at all

@endsection
