@extends('layouts.admin')
@section('content')

    // No create at all

@endsection
